﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        char test = '\u002A';
            Console.WriteLine(test);
    }
}
