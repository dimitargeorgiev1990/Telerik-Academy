﻿using System;

class IsoscelesTriangle
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine("    ©" + "\n");
        Console.WriteLine("   © ©" + "\n");
        Console.WriteLine("  ©   ©" + "\n");
        Console.WriteLine(" © © © ©" + "\n");
    }
}