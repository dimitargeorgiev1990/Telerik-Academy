﻿using System;

class DeclareVariables
{
    static void Main()
    {
        ushort first = 52130;
        sbyte second = -115;
        int third = 4825932;
        byte fourth = 97;
        short fifth = -10000;

        Console.WriteLine( "{0}\n{1}\n{2}\n{3}\n{4}\n", first, second, third, fourth, fifth);
    }
}
