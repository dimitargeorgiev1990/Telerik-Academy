﻿using System;

class VariableinHexadecimalFormat
{
    static void Main()
    {
        int hex = 0xFE;

        Console.WriteLine(hex);
    }
}
