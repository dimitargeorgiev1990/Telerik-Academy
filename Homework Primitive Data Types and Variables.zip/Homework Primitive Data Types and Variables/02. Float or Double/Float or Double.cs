﻿using System;

class FloatorDouble
{
    static void Main()
    {
        double first = 34.567839023;
        float second = 12.345F;
        double third = 8923.1234857;
        float fourth = 3456.091F;

        Console.WriteLine("{0},\n {1}, \n{2}, \n{3}",first,second,third,fourth);
    }
}