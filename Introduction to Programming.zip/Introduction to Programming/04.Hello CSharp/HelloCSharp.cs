﻿using System;

class HelloCSharp
{
    static void Main()
    {
        Console.WriteLine("HelloCSharp");
    }
}
