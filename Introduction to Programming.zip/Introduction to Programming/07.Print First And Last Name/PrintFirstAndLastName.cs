﻿using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Dimitar");
        Console.WriteLine("Georgiev");
    }
}
