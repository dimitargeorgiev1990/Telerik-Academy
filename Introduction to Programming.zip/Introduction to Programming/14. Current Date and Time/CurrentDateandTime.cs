﻿using System;
class CurrentDateandTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}
