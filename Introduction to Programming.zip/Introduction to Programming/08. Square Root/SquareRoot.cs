﻿using System;

class SquareRoot
{
    static void Main()
    {
        int number = 12345;
        Console.WriteLine(Math.Sqrt (number));
    }
}
